class TinyVGG(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_block_1 : __torch__.torch.nn.modules.container.Sequential
  conv_block_2 : __torch__.torch.nn.modules.container.___torch_mangle_7.Sequential
  classifier : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  def forward(self: __torch__.TinyVGG,
    x: Tensor) -> Tensor:
    classifier = self.classifier
    conv_block_2 = self.conv_block_2
    conv_block_1 = self.conv_block_1
    _0 = (conv_block_2).forward((conv_block_1).forward(x, ), )
    return (classifier).forward(_0, )
